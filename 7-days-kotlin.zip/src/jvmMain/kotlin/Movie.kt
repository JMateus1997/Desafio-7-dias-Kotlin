class Movie (
    val titulo: String,
    val imagem: String,
    val nota: Double,
    val ano: Int
)